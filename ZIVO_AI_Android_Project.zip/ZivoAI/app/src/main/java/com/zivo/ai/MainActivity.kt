package com.zivo.ai

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private val Night = Color(0xFF090D19)
private val Panel = Color(0xFF151C30)
private val Violet = Color(0xFF7957FF)
private val Aqua = Color(0xFF43D9E8)

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZivoScreen() }
    }
}

private fun saveMessages(context: android.content.Context, messages: List<ChatMessage>) {
    val array = JSONArray()
    messages.forEach { array.put(JSONObject().put("text", it.text).put("user", it.fromUser)) }
    context.getSharedPreferences("zivo_chat", 0).edit()
        .putString("messages", array.toString()).apply()
}

private fun readMessages(context: android.content.Context): List<ChatMessage> = try {
    val raw = context.getSharedPreferences("zivo_chat", 0).getString("messages", null)
        ?: return emptyList()
    val arr = JSONArray(raw)
    (0 until arr.length()).map {
        val obj = arr.getJSONObject(it)
        ChatMessage(obj.getString("text"), obj.getBoolean("user"))
    }
} catch (_: Exception) { emptyList() }

/*
 * Offline demo assistant: no API key, account, or internet required.
 * This is a lightweight intent/FAQ assistant, not a cloud-scale generative model.
 */
private fun zivoReply(input: String): String {
    val q = input.lowercase(Locale.getDefault())
    return when {
        q.contains("hello") || q == "hi" || q.contains("hey") ->
            "Hello! I'm ZIVO AI. What would you like help with?"
        q.contains("your name") || q.contains("who are you") ->
            "I'm ZIVO AI, your on-device assistant."
        q.contains("time") ->
            "Your phone's current time is shown in its status bar. I work offline and don't read private device data."
        q.contains("date") || q.contains("today") ->
            "Today is ${java.time.LocalDate.now()}."
        q.contains("calculate") || q.matches(Regex(".*\\d+\\s*[+*/%-]\\s*\\d+.*")) ->
            "I can help with simple calculations. Try asking a clear question such as: calculate 12 + 8."
        q.contains("12 + 8") -> "12 + 8 = 20."
        q.contains("help") || q.contains("what can you do") ->
            "I can answer a few built-in questions, greet you, tell you today's date, and keep your chat on this phone. This free starter edition works offline."
        q.contains("android") || q.contains("phone") ->
            "For Android help, tell me your phone model and what you're trying to do. I'll do my best with the built-in help topics."
        q.contains("thank") -> "You're welcome! Ask me something else."
        else ->
            "I'm ZIVO AI's free offline starter assistant. I don't have a full language model installed, so I may not understand that yet. You can still ask for help, greetings, or today's date."
    }
}

@Composable
private fun ZivoLogo() {
    Box(
        modifier = Modifier
            .size(48.dp)
            .background(Brush.linearGradient(listOf(Violet, Aqua)), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text("Z", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
fun ZivoScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val listState = rememberLazyListState()
    var messages by remember {
        mutableStateOf(readMessages(context).ifEmpty {
            listOf(ChatMessage("Hi! I'm ZIVO AI. I'm ready to help. Ask me “What can you do?”", false))
        })
    }
    var input by remember { mutableStateOf("") }

    LaunchedEffect(messages) { saveMessages(context, messages) }
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            input = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull().orEmpty()
        }
    }

    fun send() {
        val prompt = input.trim()
        if (prompt.isBlank()) return
        messages = messages + ChatMessage(prompt, true) + ChatMessage(zivoReply(prompt), false)
        input = ""
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Violet, background = Night, surface = Panel
    )) {
        Column(Modifier.fillMaxSize().background(Night)) {
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ZivoLogo()
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("ZIVO AI", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("Your personal offline assistant", color = Aqua, fontSize = 12.sp)
                }
                TextButton(onClick = {
                    messages = listOf(ChatMessage("New chat started. How can I help?", false))
                }) { Text("NEW", color = Aqua) }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages) { message ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        if (!message.fromUser) {
                            Box(
                                Modifier.size(30.dp).background(
                                    Brush.linearGradient(listOf(Violet, Aqua)), CircleShape
                                ),
                                contentAlignment = Alignment.Center
                            ) { Text("Z", color = Color.White, fontWeight = FontWeight.Bold) }
                            Spacer(Modifier.width(7.dp))
                        }
                        Surface(
                            color = if (message.fromUser) Violet else Panel,
                            shape = RoundedCornerShape(17.dp),
                            modifier = Modifier.widthIn(max = 290.dp)
                        ) {
                            Text(
                                message.text, color = Color.White, fontSize = 15.sp,
                                lineHeight = 21.sp, modifier = Modifier.padding(13.dp)
                            )
                        }
                    }
                }
            }

            Column(Modifier.fillMaxWidth().background(Panel).padding(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Ask ZIVO anything...") },
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { send() }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Violet,
                            unfocusedBorderColor = Color.Gray,
                            focusedContainerColor = Night,
                            unfocusedContainerColor = Night
                        )
                    )
                    Spacer(Modifier.width(6.dp))
                    FilledTonalButton(onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to ZIVO")
                        }
                        try { speechLauncher.launch(intent) } catch (_: Exception) { }
                    }) { Text("🎤") }
                    Spacer(Modifier.width(4.dp))
                    Button(onClick = { send() }, enabled = input.isNotBlank()) { Text("➤") }
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("FREE • OFFLINE STARTER", color = Color.LightGray, fontSize = 10.sp)
                    TextButton(onClick = {
                        messages = listOf(ChatMessage("Chat cleared. I'm ready!", false))
                    }) { Text("Clear chat", color = Aqua, fontSize = 11.sp) }
                }
            }
        }
    }
}
